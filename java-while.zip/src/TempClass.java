
@HelloCheck("안녕하세요")
public class TempClass {

    @HelloCheck("감사합니다")
    void hello(){

    }
}
